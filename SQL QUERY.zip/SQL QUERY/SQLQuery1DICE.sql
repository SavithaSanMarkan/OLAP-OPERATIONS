

Select brand, model_year, sum(sales) from sales.sales_summary where category= 'Electric Bikes' and model_year = '2018' group by brand, model_year;