
Select brand, sum(sales) as Sales from sales.sales_summary where category= 'Mountain Bikes' GROUP  BY brand;